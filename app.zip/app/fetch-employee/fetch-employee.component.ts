import { Component, OnInit } from '@angular/core';
import { MyserviceService } from '../my-service.service';
import { Employee } from '../Employee';

@Component({
  selector: 'app-fetch-employee',
  templateUrl: './fetch-employee.component.html',
  styleUrls: ['./fetch-employee.component.css']
})
export class FetchEmployeeComponent implements OnInit {
  service:MyserviceService;
  
  constructor(service:MyserviceService) {
    this.service=service;
 
   }
   employee:Employee[]=[];
   delete(dptId:number)
   {
     this.service.delete(dptId);
     this.employee=this.service.getEmployees();
   }

   column:string="dptId"; 
   order:boolean=true;
   sort(column:string){
     //
     //if the click is for same column ,change the previous order
     // else order for ascending by default
     //  
     if(this.column==column )
     {
       this.order=!this.order;
     }else{
       this.order=true;
       this.column=column;
     }
   }

 ngOnInit() {
   this.service.fetchEmployees();
   this.employee=this.service.getEmployees();
 }

}
