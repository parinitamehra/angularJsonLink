import { Component, OnInit } from '@angular/core';
import { MyserviceService } from '../my-service.service';
import { Employee } from '../Employee';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
employee:Employee[]=[];
  updatedEmployee:Employee;
  service:MyserviceService;
    constructor(service:MyserviceService) {
      this.service=service;
     }

  ngOnInit() {
  }
update(data:any)
{
  this.service.update(data);
  this.employee=this.service.getEmployees();
}
}
