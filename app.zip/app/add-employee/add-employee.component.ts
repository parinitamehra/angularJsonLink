import { Component, OnInit } from '@angular/core';
import { MyserviceService } from '../my-service.service';
import { Employee } from '../Employee';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {
  createdEmployee:Employee;
service:MyserviceService;
  constructor(service:MyserviceService) {
    this.service=service;
   }

  ngOnInit() {
   
  }
add(data:any)
{
  this.createdEmployee=new Employee(data.dptId,data.dptName);
  this.service.add(this.createdEmployee);
  
}

}
