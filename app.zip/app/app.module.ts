import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { FetchEmployeeComponent } from './fetch-employee/fetch-employee.component';

import { HttpClient, HttpClientModule } from "@angular/common/http";
import { FormsModule } from "@angular/forms";
import { MyserviceService } from './my-service.service';
import { UpdateComponent } from './update/update.component';
import { OrderByPipe } from './order-by.pipe';
import { SearchComponent } from './search/search.component';



@NgModule({
  declarations: [
    AppComponent,
    AddEmployeeComponent,
    FetchEmployeeComponent,
    UpdateComponent,
    OrderByPipe,
    SearchComponent
  
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,HttpClientModule,FormsModule
  ],
  providers: [MyserviceService,HttpClient],
  bootstrap: [AppComponent]
})
export class AppModule { }
