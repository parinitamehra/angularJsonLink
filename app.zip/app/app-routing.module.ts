import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {FetchEmployeeComponent} from './fetch-employee/fetch-employee.component'
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { UpdateComponent } from './update/update.component';
import { SearchComponent } from './search/search.component';

const routes: Routes = [
  {
    path:"show",
    component:FetchEmployeeComponent
  },
  {
    path:"add",
    component:AddEmployeeComponent
  },
  {
    path:"update",
    component:UpdateComponent
  },
  {
    path:"search",
    component:SearchComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
