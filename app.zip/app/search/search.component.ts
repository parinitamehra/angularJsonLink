import { Component, OnInit } from '@angular/core';
import { MyserviceService } from '../my-service.service';
import { Employee } from '../Employee';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
service:MyserviceService;
employee:Employee[]=[];
  constructor(service:MyserviceService) {
    this.service=service;
   }

  ngOnInit() {
    this.service.fetchEmployees();
  }
  search(data:any)
  {
   // this.service.search(dptId);
   // this.employee=this.service.getEmployees();
   let dptId:number=data.dptId;
   this.employee=this.service.search(dptId);


  }
}
