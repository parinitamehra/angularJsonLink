import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { Employee } from './Employee';

@Injectable({
  providedIn: 'root'
})
 
export class MyserviceService {
  http:HttpClient;
  employee:Employee[]=[];
    constructor(http:HttpClient) {
      this.http=http;
     }
  fetched:boolean;
  fetchEmployees()
  {
    this.http.get('./assets/department.json').subscribe(data=>
     {
       if(!this.fetched)
      {
        this.convert(data);
    this.fetched=true;
      }
  }
   );
  }
  
  getEmployees():Employee[]
  {
    return this.employee;
  }
  
  convert(data:any)
  {
    // for(let o of data)
    // {
    //   let e=new Employee(o.dptId,o.dptName);
    //   this.employee.push(e);
    // }
    for(let o in data)
    {
      for(let i of data[o])
      {
        let e = new Employee(i.dptId,i.dptName);
        this.employee.push(e)
      }
    }
  }
  delete(eid:number)
  {
    let foundIndex:number=-1;
    for(let i=0;i<this.employee.length;i++)
    {
      let e= this.employee[i];
      if(eid==e.dptId)
      {
        foundIndex=i;
        break;
      }
    }
    this.employee.splice(foundIndex,1);
  }
  
  add(e:Employee)
  {
    this.employee.push(e);
  }
  update(data:any)
  {
    let dptId=data.dptId;
    let dptName=data.dptName;
    for(let i=0;i<this.employee.length;i++)
    {
      let e=this.employee[i];
      if(dptId==e.dptId)
      {
        e.dptId=dptId;
        e.dptName=dptName;
      }
    }
  }
  search(dptId:number):Employee[]
  {
let resultDept:Employee[]=[];
let o:Employee;
var flag=0;
for(let i=0;i<this.employee.length;i++)
{
  o=this.employee[i];
  //console.log(o);
  if(dptId==o.dptId)
  {
    resultDept.push(o);
    alert(o.dptId + " " + o.dptName);
    flag=1;
    console.log(flag);
  }
}
if(flag==0)
{
  alert(dptId+ "dosen't exist");
}
return resultDept;
  }
  }

  
